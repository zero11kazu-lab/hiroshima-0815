// The characters and this story are fictional. The sequence uses elapsed seconds, not nested timers.
const ENDING_STATES=['MASAMI_REUNION','ESCAPE_SEQUENCE','FADE_AFTER_ESCAPE','THIRTY_DAYS_LATER','RADIATION_EXPLANATION','TATAMI_ROOM','MASAMI_FINAL_DIALOGUE','MASAMI_DEATH','KAZUO_GRIEF','FINAL_BLACKOUT','MEMORIAL','THE_END'];
const FINAL_DIALOGUE=[
 {seconds:7,text:'マサミ「あの焼け野原の中を……私を探して、見つけてくれてありがとうね……。」'},
 {seconds:7,text:'一雄「当たり前じゃ。お前を置いていけるわけがない。ずっと探しとった。」'},
 {seconds:8,text:'マサミ「見つけてくれた時……本当にうれしかった……。一緒にいてくれて……ありがとう……。」'},
 {seconds:7,text:'一雄「礼を言うのは俺のほうだ。生きていてくれて、会えて、それだけでよかった。」'},
 {seconds:6,text:'マサミ「一雄と……夫婦でいられて……幸せだった……。」'},
 {seconds:7,text:'一雄「わしもじゃ。お前と一緒になれて、本当によかった。ずっとそばにおる。」'},
 {seconds:5,text:'マサミ「……ありがとう……。」'}
];
const ENDING_DURATIONS=[6,8,3,3,25,5,FINAL_DIALOGUE.reduce((sum,line)=>sum+line.seconds,0),12,6,3,9.5,9];
const MEMORIAL_MESSAGE='「こがぁな、わしみたいな小さいもんが、どんなあやまちをしたいうて、こがぁに辛い思いをせにゃぁいけんのんかのぉ……」';
const RADIATION_TEXT=[
 '原爆は爆風と熱線だけでなく、放射線も放った。',
 '強い被曝後、数日のうちに疲労、吐き気、食欲低下や下痢が現れることがある。',
 'いったん落ち着いて見えても、数週間のうちに発熱、口内炎、脱毛や出血が現れることがある。',
 '骨髄が損傷すると血球が減り、出血や感染により数週間から１、２か月以内に命を落とす場合もあった。',
 '架空の人物マサミは、被曝後に重度の急性放射線症を発症し、次第に衰弱した。'
];
class EndingSequence {
 constructor(){this.active=false;this.state='GAMEPLAY_POST_BLAST';this.time=0;this.index=0;this.gameplayCompleted=false;this.durations=ENDING_DURATIONS;this.audioNodes=[];this.musicMode='';this.musicClock=0;}
 reset(){$('ending-return-title').hidden=true;$('ending-return-title').disabled=true;this.stopAudio();this.active=false;this.state='GAMEPLAY_POST_BLAST';this.gameplayCompleted=false;this.index=0;this.time=0;if(this.room)this.room.visible=false;const e=$('ending-overlay');if(e){e.hidden=true;e.classList.remove('is-memorial');}$('ending-memorial').hidden=true;document.body.classList.remove('ending-active');}
 begin(){if(this.active||this.gameplayCompleted)return;this.active=true;this.gameplayCompleted=true;this.index=0;this.time=0;this.state=ENDING_STATES[0];this.escapeStart={x:pos.x,z:pos.z};this.wifeStart={...postMissions.wife.position};stop();playerControlEnabled=cameraManualControlEnabled=false;if(dialogue.active)dialogue.close();$('talk').hidden=true;document.body.classList.add('event-active','ending-active');$('ending-overlay').hidden=false;ambientAudio.stop();this.audio('ending');}
 // The music is original, synthesized, and connected to the existing limiter. Only one track is active.
 audio(mode){if(mode==='ending'&&this.musicMode==='post'&&this.audioGain&&morningAudio.ctx?.state==='running'){const c=morningAudio.ctx,g=this.audioGain,nodes=this.audioNodes.slice(),t=c.currentTime;g.gain.cancelScheduledValues(t);g.gain.setValueAtTime(g.gain.value,t);g.gain.linearRampToValueAtTime(0,t+.6);for(const n of nodes)try{n.stop?.(t+.65);}catch(_){}this.audioNodes=[];this.audioGain=null;setTimeout(()=>{for(const n of nodes)try{n.disconnect();}catch(_){}},800);}else this.stopAudio();this.musicMode=mode;this.musicClock=0;this.nextNote=0;this.noteIndex=0;this.ensureAudio();}
 ensureAudio(){const c=morningAudio.ctx;if(this.audioGain||!this.musicMode||!c||c.state!=='running'||!morningAudio.enabled)return;const gain=c.createGain(),now=c.currentTime;gain.gain.setValueAtTime(.0001,now);const start=now+(this.musicMode==='ending'?.65:0);gain.gain.setValueAtTime(.0001,start);gain.gain.linearRampToValueAtTime(this.musicMode==='post'?.36:this.state==='MEMORIAL'?.018:.24,start+1.2);gain.connect(morningAudio.master);this.audioGain=gain;this.audioNodes.push(gain);
  if(this.musicMode==='post')for(const [i,f] of [110,164.81,174.61].entries()){const o=c.createOscillator(),g=c.createGain();o.type=i===0?'sine':'triangle';o.frequency.value=f;g.gain.value=i===0?.13:.085;o.connect(g);g.connect(gain);o.start();this.audioNodes.push(o,g);}}
 note(f,d=2,volume=.2){const c=morningAudio.ctx;if(!this.audioGain||!c||c.state!=='running')return;const o=c.createOscillator(),g=c.createGain(),t=c.currentTime;o.type='sine';o.frequency.value=f;g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(volume,t+.08);g.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(g);g.connect(this.audioGain);o.start(t);o.stop(t+d+.02);o.onended=()=>{o.disconnect();g.disconnect();};}
 stopAudio(){for(const n of this.audioNodes){try{n.stop?.();}catch(_){}try{n.disconnect();}catch(_){}}this.audioNodes=[];this.audioGain=null;this.musicMode='';}
 music(dt){if(!this.musicMode)return;this.ensureAudio();if(!this.audioGain)return;this.musicClock+=dt;
  if(this.musicClock>=this.nextNote){if(this.musicMode==='post'){
   // Sparse, unresolved original phrase, with audible midrange for phone speakers.
   const phrase=[329.63,311.13,392,349.23,277.18,311.13,369.99,293.66],durations=[3.4,4.4,3,5,3.6,4.2,3.2,5.2],i=Math.floor(this.noteIndex||0)%phrase.length;
   this.note(phrase[i],durations[i],.25);this.noteIndex=i+1;this.nextNote=this.musicClock+[3.1,4.5,2.8,5][i%4];
  }else if(this.state!=='MEMORIAL'&&(this.state!=='THE_END'||this.time<5)){const notes=[220,261.63,329.63,293.66,261.63,196,220,246.94];this.note(notes[Math.floor(this.nextNote/1.5)%notes.length],2.3,.23);this.nextNote+=1.5;}}
  if(this.musicMode==='ending'&&this.state==='THE_END'&&this.time>4)this.audioGain.gain.setTargetAtTime(0,morningAudio.ctx.currentTime,1.5);
 }
 endingTexture(kind){this.roomTextures=this.roomTextures||{};if(this.roomTextures[kind])return this.roomTextures[kind];const c=document.createElement('canvas');c.width=c.height=256;const g=c.getContext('2d');g.fillStyle=kind==='tatami'?'#a39a70':kind==='cloth'?'#ccc4ae':'#c8bea7';g.fillRect(0,0,256,256);for(let i=0;i<256;i++){g.strokeStyle=i%3?'#00000009':'#ffffff18';g.beginPath();g.moveTo(0,i);g.lineTo(256,i);g.stroke();}for(let i=0;i<256;i+=4){g.fillStyle='#655d4310';g.fillRect(i,0,1,256);}const map=new THREE.CanvasTexture(c);this.roomTextures[kind]=map;return map;}
 buildRoom(){if(this.room)return;this.room=new THREE.Group();this.room.position.set(0,-100,0);scene.add(this.room);box(8,.2,7,'#a89b77',0,0,0,this.room);for(let x=-3;x<=3;x+=1.5)box(.04,.01,7,'#5f6351',x,.11,0,this.room);box(8,4,.12,'#a69c87',0,2,-3.5,this.room);for(let x=-3;x<=3;x+=1.5){box(1.35,2.8,.06,'#d5cdb5',x,1.7,-3.41,this.room);for(let y=.6;y<3;y+=.7)box(1.35,.035,.08,'#736b5b',x,y,-3.35,this.room);}box(2.1,.24,3,'#d5cdbb',.8,.24,0,this.room);box(1.4,.18,1.4,'#b5aa95',.8,.43,.4,this.room);this.buildRoomCharacters();for(const mesh of this.room.children){if(!mesh.isMesh)continue;const material=mesh.material.clone();material.map=this.endingTexture(mesh.scale.y<.3?'cloth':mesh.scale.y>2?'paper':'tatami');mesh.material=material;}this.room.children[0].material.map=this.endingTexture('tatami');}
 // Reuse the playable character hierarchy and the NPC renderer's exact part layout.
 // This is a visual-only copy: no NPC, AI, mission or input is registered here.
 buildRoomCharacters(){
  this.roomKazuo=new THREE.Group();this.roomKazuo.position.set(-.85,.17,-.1);this.roomKazuo.rotation.y=-Math.PI/2;this.room.add(this.roomKazuo);
  this.kazuoModel=player.clone(true);this.kazuoModel.position.set(0,-.35,0);this.kazuoModel.rotation.set(0,0,0);this.roomKazuo.add(this.kazuoModel);
  // Restore only the room copy; the field player's damaged appearance stays intact.
  if(player.preDamageMaterials){let index=0;this.kazuoModel.traverse(m=>{if(m.isMesh)m.material=player.preDamageMaterials[index++].material;});}
  this.kazuoModel.userData.damageAppearance='PRE';
  for(const child of [...this.kazuoModel.children])if(child.geometry?.type==='CircleGeometry')this.kazuoModel.remove(child);
  // Clone indices are captured before removal of the trailing ground shadow.
  for(const leg of legs)this.kazuoModel.children[player.children.indexOf(leg)].rotation.x=-Math.PI/2;
  this.kazuoArms=arms.map(a=>this.kazuoModel.children[player.children.indexOf(a)]);
  for(const arm of this.kazuoArms)arm.rotation.x=-.45;
  this.roomMasami=new THREE.Group();this.roomMasami.position.set(.8,.59,1.1);this.roomMasami.rotation.x=-Math.PI/2;this.room.add(this.roomMasami);
  const model=new THREE.Group(),wife=postMissions.wife,source=npcManager.visuals,colors=new THREE.Color();
  model.rotation.y=Math.PI;model.scale.setScalar(wife.height);this.roomMasami.add(model);this.masamiModel=model;
  const visual=Object.create(source);visual.root=new THREE.Object3D();
  visual.part=(batch,index,x,y,z,sx,sy,sz,rx=0)=>{
   if(batch===source.shadows||!sx||!sy||!sz)return;
   if(wife.preAppearance){const original=batch===source.boxes?wife.preAppearance.boxes[index%source.parts]:batch===source.heads?wife.preAppearance.head:batch===source.hats?wife.preAppearance.hat:wife.preAppearance.skirt;colors.copy(original);}else batch.getColorAt(index,colors);const mesh=new THREE.Mesh(batch.geometry,mat('#'+colors.getHexString()));
   mesh.position.set(x,y,z);mesh.scale.set(sx,sy,sz);mesh.rotation.x=rx;model.add(mesh);
   if(batch===source.boxes&&index===wife.index*source.parts)this.masamiChest=mesh;
  };
  source.write.call(visual,{...wife,roomAppearance:true,position:{...pos},yaw:0,eventTilt:0,eventRoll:0,moving:false,hiddenFromWorld:false},true);
  // Preserve the existing restrained hair-on-pillow detail.
  const hair=box(.26,.02,.05,'#524e47',1.25,.4,-.8,this.room);hair.rotation.y=.5;
 }
 roomPerformance(s,t,title){
  const dying=s==='MASAMI_DEATH',still=['KAZUO_GRIEF','FINAL_BLACKOUT'].includes(s);
  const strength=still?0:dying?Math.max(0,1-t/3):1;
  // Chest movement alone weakens over three seconds, then stays completely still.
  this.masamiChest.scale.z=.31*(1+Math.sin(t*(dying?2:2.7))*.04*strength);
  this.roomMasami.position.y=.59;
  if(s==='TATAMI_ROOM'&&t>1&&t<3){this.roomMasami.position.y+=.008*Math.sin(t*14);title.textContent='マサミ「……こほっ、こほっ。」';}
  this.kazuoModel.rotation.x=0;this.kazuoModel.position.y=-.35;
  for(const arm of this.kazuoArms)arm.rotation.x=-.45;
  if(s==='MASAMI_FINAL_DIALOGUE'){
   let remaining=t;for(const line of FINAL_DIALOGUE){title.textContent=line.text;if(remaining<line.seconds)break;remaining-=line.seconds;}
  }
  if(dying)title.textContent=t<3?'':t<5?'一雄「……マサミ？」':t<7?'一雄「マサミ……」':t<9?'一雄「マサミ！！」':'マサミは、一雄に見守られながら静かに息を引き取った。';
  if(s==='KAZUO_GRIEF'||s==='FINAL_BLACKOUT'){
   const grief=s==='KAZUO_GRIEF'?t:6,lean=eventEase(Math.min(grief/2,1));
   this.kazuoModel.rotation.x=-.7*lean+(s==='KAZUO_GRIEF'?Math.sin(t*7)*.025*lean:0);
   this.kazuoModel.position.y=-.35-.12*lean;
   for(const arm of this.kazuoArms)arm.rotation.x=-.45-.75*lean;
   if(s==='KAZUO_GRIEF')title.textContent='一雄「マサミ……ううっ……」';
  }
 }

 jump(state){if(!EVENT_DEBUG)return;this.begin();const i=ENDING_STATES.indexOf(state);if(i<0)return;this.index=i;this.state=state;this.time=0;if(this.room)this.room.visible=i>=5&&i<10;this.render();}
 update(dt){if(!this.active)return;this.music(dt);const before=this.state;this.time+=dt;while(this.time>=this.durations[this.index]&&this.index<ENDING_STATES.length-1){this.time-=this.durations[this.index++];this.state=ENDING_STATES[this.index];}if(before!==this.state){if(this.state==='MEMORIAL'&&this.audioGain){const now=morningAudio.ctx.currentTime;this.audioGain.gain.cancelScheduledValues(now);this.audioGain.gain.setTargetAtTime(.018,now,.9);}if(this.state==='TATAMI_ROOM'){this.note(165,.3,.1);this.note(140,.4,.06);}if(this.state==='KAZUO_GRIEF'){this.note(155,1.1,.18);this.note(185,1.7,.09);}}this.render();}
 render(){const e=$('ending-overlay'),title=$('ending-text'),t=this.time,s=this.state;const back=$('ending-return-title');back.hidden=s!=='THE_END';back.disabled=s!=='THE_END'||t<3.7||titleScreen.returning;back.style.opacity=s==='THE_END'?eventEase((t-3.7)/1.2):0;e.style.background='transparent';title.textContent='';title.style.fontSize='';title.style.fontFamily='';title.style.opacity='1';title.style.fontWeight='';title.style.textShadow='';e.classList.toggle('is-memorial',s==='MEMORIAL');$('ending-memorial').hidden=s!=='MEMORIAL';
  if(s==='MASAMI_REUNION'){title.textContent=t<2?'一雄「マサミ！」':t<4?'マサミ「一雄……。」':'一雄「ここを出よう。」';camera.position.lerp(new THREE.Vector3(pos.x+2,2.8,pos.z+4),.02);camera.lookAt(postMissions.wife.position.x,1,postMissions.wife.position.z);}
  else if(s==='ESCAPE_SEQUENCE'){const w=postMissions.wife,d=Math.min(t*.3,2.4);player.position.set(this.escapeStart.x,.08,this.escapeStart.z-d);w.position.x=this.wifeStart.x;w.position.z=this.wifeStart.z-d;player.rotation.y=Math.PI;legs.forEach((l,i)=>l.rotation.x=Math.sin(t*5+i*Math.PI)*.3);arms.forEach((a,i)=>a.rotation.x=-Math.sin(t*5+i*Math.PI)*.25);w.yaw=Math.PI;w.phase=t*5;w.moving=true;npcManager.visuals.write(w,true);npcManager.visuals.flush();camera.position.set(this.escapeStart.x,3.5,this.escapeStart.z+6+t*.14);camera.lookAt(this.escapeStart.x,1,this.escapeStart.z-d);hazards.animate(t);}
  else if(s==='FADE_AFTER_ESCAPE')e.style.background=`rgba(0,0,0,${eventEase(t/3)})`;
  else if(s==='THIRTY_DAYS_LATER'){e.style.background='#000';title.textContent='30日後';}
  else if(s==='RADIATION_EXPLANATION'){e.style.background='#000';title.textContent=RADIATION_TEXT[Math.min(4,Math.floor(t/5))];}
  else if(['TATAMI_ROOM','MASAMI_FINAL_DIALOGUE','MASAMI_DEATH','KAZUO_GRIEF','FINAL_BLACKOUT'].includes(s)){this.buildRoom();this.room.visible=true;const roomTime=s==='TATAMI_ROOM'?t:s==='MASAMI_FINAL_DIALOGUE'?5+Math.min(t/8,5):10;camera.position.set(5-roomTime*.06,-96.3,6-roomTime*.06);camera.lookAt(0,-99.1,0);this.roomPerformance(s,t,title);if(s==='FINAL_BLACKOUT')e.style.background=`rgba(0,0,0,${eventEase(t/3)})`;}
  else if(s==='MEMORIAL'){
   e.style.background='#000';if(this.room)this.room.visible=false;
   const background=eventEase(t/.9)*(1-eventEase((t-8.8)/.7));
   $('ending-memorial').style.opacity=String(background);
   title.style.opacity=String(eventEase((t-.7)/1)*(1-eventEase((t-7.2)/1)));
   for(const text of MEMORIAL_MESSAGE.split(/(?=こがぁに)/)){const line=document.createElement('span');line.className='memorial-line';line.textContent=text;title.appendChild(line);}
  }
  else if(s==='THE_END'){e.style.background='#000';title.style.fontSize='min(38vw, 65dvh)';title.style.fontFamily='YuMincho, Hiragino Mincho ProN, serif';title.style.fontWeight='900';title.style.opacity=eventEase((t-.7)/1.2);title.style.textShadow='1px 1px 2px #e8deca, -1px 0 1px #e8deca';title.textContent=t<.7?'':'【完】';}
 }
}
const ending=new EndingSequence();
