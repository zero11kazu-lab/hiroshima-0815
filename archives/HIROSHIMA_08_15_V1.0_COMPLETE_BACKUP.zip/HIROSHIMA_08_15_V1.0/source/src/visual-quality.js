// Bounded 256px procedural textures. Offline, no extra downloads; shared across every building.
const surfaceCache=new Map(),textureCache=new Map();
function surfaceTexture(kind){
 if(textureCache.has(kind))return textureCache.get(kind);
 const c=document.createElement('canvas');c.width=c.height=256;const g=c.getContext('2d');let seed=815;
 const rnd=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
 g.fillStyle={timber:'#a69b81',plaster:'#d5ceae',earth:'#b3a084',tile:'#92958d',stone:'#b7afa1',dirt:'#b7aa8b',gravel:'#bbb5a4',char:'#625a50',water:'#7da8a4'}[kind]||'#a9a095';g.fillRect(0,0,256,256);
 for(let i=0;i<6500;i++){const v=rnd()>.5?255:15;g.fillStyle=`rgba(${v},${v},${v},${.025+rnd()*.075})`;const x=rnd()*256,y=rnd()*256;g.fillRect(x,y,kind==='timber'?1:1+rnd()*3,kind==='timber'?10+rnd()*30:1+rnd()*3);}
 if(kind==='timber'){for(let x=0;x<256;x+=32){g.fillStyle='rgba(25,20,14,.42)';g.fillRect(x,0,2,256);g.fillStyle='rgba(240,220,185,.18)';g.fillRect(x+2,0,1,256);}}
 if(kind==='tile'){for(let y=0;y<256;y+=32)for(let x=0;x<256;x+=24){const off=(y/32%2)*12;g.fillStyle='rgba(30,34,35,.36)';g.fillRect(x+off,y,2,32);g.fillRect(x+off,y+28,24,4);g.fillStyle='rgba(240,240,225,.22)';g.fillRect(x+off+5,y+3,3,24);}}
 if(kind==='stone'){for(let y=0;y<256;y+=42){g.fillStyle='rgba(40,35,28,.28)';g.fillRect(0,y,256,3);for(let x=(y/42%2)*32;x<256;x+=64)g.fillRect(x,y,2,42);}}
 if(kind==='water'){g.strokeStyle='rgba(220,239,219,.26)';g.lineWidth=1;for(let i=0;i<50;i++){const y=rnd()*256;g.beginPath();g.moveTo(0,y);g.bezierCurveTo(80,y-5,170,y+5,256,y);g.stroke();}}
 const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.colorSpace=THREE.SRGBColorSpace;t.anisotropy=2;textureCache.set(kind,t);return t;
}
function surface(kind,color='#ffffff',pbr=false){const key=kind+color+pbr;if(surfaceCache.has(key))return surfaceCache.get(key);const options={map:surfaceTexture(kind),color};const m=pbr?new THREE.MeshStandardMaterial({...options,roughness:kind==='water'?.32:.9,metalness:kind==='water'?.12:0}):new THREE.MeshLambertMaterial(options);surfaceCache.set(key,m);return m;}
function texturedBox(w,h,d,material,x,y,z,parent=scene){const m=new THREE.Mesh(geometries.box,material);m.scale.set(w,h,d);m.position.set(x,y,z);parent.add(m);return m;}
function texturedPlane(w,d,material,x,z,repeat=4){const g=new THREE.PlaneGeometry(w,d);const uv=g.attributes.uv;for(let i=0;i<uv.count;i++)uv.setXY(i,uv.getX(i)*w/repeat,uv.getY(i)*d/repeat);const m=new THREE.Mesh(g,material);m.rotation.x=-Math.PI/2;m.position.set(x,.04,z);scene.add(m);return m;}
// Subtract already-drawn road rectangles so intersections have exactly one surface.
// Keep original road bounds, UV origin, material, height and collider data unchanged.
function roadSurfaceGeometry(road,covered,repeat=3){
 let pieces=[{minX:road.x-road.w/2,maxX:road.x+road.w/2,minZ:road.z-road.d/2,maxZ:road.z+road.d/2}];
 for(const other of covered){
  const next=[];
  for(const p of pieces){
   const x0=Math.max(p.minX,other.x-other.w/2),x1=Math.min(p.maxX,other.x+other.w/2),z0=Math.max(p.minZ,other.z-other.d/2),z1=Math.min(p.maxZ,other.z+other.d/2);
   if(x0>=x1||z0>=z1){next.push(p);continue;}
   if(p.minX<x0)next.push({...p,maxX:x0});
   if(x1<p.maxX)next.push({...p,minX:x1});
   if(p.minZ<z0)next.push({minX:x0,maxX:x1,minZ:p.minZ,maxZ:z0});
   if(z1<p.maxZ)next.push({minX:x0,maxX:x1,minZ:z1,maxZ:p.maxZ});
  }pieces=next;
 }
 if(!pieces.length)return null;
 const positions=[],uvs=[];
 for(const p of pieces)for(const [x,z]of [[p.minX,p.maxZ],[p.maxX,p.maxZ],[p.minX,p.minZ],[p.maxX,p.maxZ],[p.maxX,p.minZ],[p.minX,p.minZ]]){
  positions.push(x-road.x,road.z-z,0);uvs.push((x-road.x+road.w/2)/repeat,(road.z+road.d/2-z)/repeat);
 }
 const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));geometry.computeVertexNormals();return geometry;
}
function districtGround(world){
 world.surfaces=[];const ground=texturedPlane(145,145,surface('dirt','#c0b99c'),0,-7,5);ground.position.y=-.015;world.surfaces.push({mesh:ground,pre:ground.material,post:surface('char','#78756c')});
 const coveredRoads=[];
 for(const r of world.data.roads){const geometry=roadSurfaceGeometry(r,coveredRoads);coveredRoads.push(r);if(!geometry)continue;const m=new THREE.Mesh(geometry,surface(r.tram?'gravel':'dirt',r.tram?'#d0c7ad':'#c3b79d'));m.rotation.x=-Math.PI/2;m.position.set(r.x,.015,r.z);scene.add(m);world.surfaces.push({mesh:m,pre:m.material,post:surface('char','#8b8476')});}
 for(const r of GEO1945.rivers){const shape=new THREE.Shape();r.polygon.forEach((p,i)=>i?shape.lineTo(p[0],-p[1]):shape.moveTo(p[0],-p[1]));shape.closePath();const geom=new THREE.ShapeGeometry(shape);const uv=geom.attributes.uv;for(let i=0;i<uv.count;i++)uv.setXY(i,uv.getX(i)/9,uv.getY(i)/9);const m=new THREE.Mesh(geom,surface('water','#91b5b0',true));m.rotation.x=-Math.PI/2;m.position.y=.025;m.userData.nonSolid=true;scene.add(m);
 // Sloped stone banks follow the staged bank line, not the old fictional cross-town river.
 for(const side of r.id==='motoyasu'?[[1,2],[2,3],[3,4]]:[[0,7],[7,6],[6,5]])for(const [a,b] of [side]){const p=r.polygon[a],q=r.polygon[b],len=Math.hypot(q[0]-p[0],q[1]-p[1]),bank=texturedBox(.55,.5,len,surface('stone','#8b8877'),(p[0]+q[0])/2,.02,(p[1]+q[1])/2);bank.rotation.y=Math.atan2(q[0]-p[0],q[1]-p[1]);bank.userData.nonSolid=true;}}
 for(const b of GEO1945.bridges){const g=new THREE.Group();g.position.set(b.x,0,b.z);texturedBox(b.w,.28,b.d,surface('stone','#b7b19c'),0,.1,0,g);for(const z of [-b.d/2,b.d/2]){texturedBox(b.w,.13,.16,surface('stone','#c6c1ae'),0,1.1,z,g);for(let x=-b.w/2+.5;x<b.w/2;x+=2){texturedBox(.21,1.05,.24,surface('stone','#a49f8e'),x,.55,z,g);box(1.4,.08,.08,'#777a6d',x+.8,.65,z,g);}block(b.x,b.z+z,b.w,.2);}for(const x of [-5,5])texturedBox(1.2,1.3,b.d*.8,surface('stone','#777f77'),x,-.45,0,g);world.mergeDetails(g);world.addGroup(g,b.x,b.z);}
 // Shared LineSegments for rails and suspended contact wire. Track alignments are schematic.
 const points=[],wires=[];for(const r of world.data.roads.filter(r=>r.tram)){const alongZ=r.d>r.w;for(const o of [-1.7,-.7,.7,1.7]){const p=alongZ?[[r.x+o,r.z-r.d/2],[r.x+o,r.z+r.d/2]]:[[r.x-r.w/2,r.z+o],[r.x+r.w/2,r.z+o]];points.push(new THREE.Vector3(p[0][0],.26,p[0][1]),new THREE.Vector3(p[1][0],.26,p[1][1]));}const p=alongZ?[[r.x,r.z-r.d/2],[r.x,r.z+r.d/2]]:[[r.x-r.w/2,r.z],[r.x+r.w/2,r.z]];wires.push(new THREE.Vector3(p[0][0],5.6,p[0][1]),new THREE.Vector3(p[1][0],5.6,p[1][1]));}
 for(const [ps,col] of [[points,'#665f50'],[wires,'#565b56']]){const m=new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(ps),new THREE.LineBasicMaterial({color:col}));m.userData.nonSolid=true;scene.add(m);}
 // Stationary period-inspired tram. No unsupported vehicle number or historical livery claim.
 const tram=new THREE.Group();tram.position.set(1.2,0,-55);tram.userData.preBlast=true;tram.userData.tram=true;world.tram=tram;texturedBox(1.75,1.35,5.6,surface('timber','#586e59'),0,1.25,0,tram);box(1.8,.65,5.7,'#d1c7a8',0,2.2,0,tram);for(const side of [-1,1])for(let z=-2;z<=2;z+=.8){box(.04,.48,.58,'#516969',side*.92,2.2,z,tram);box(.045,.5,.04,'#d6c9a7',side*.95,2.2,z+.3,tram);}box(1.95,.18,5.9,'#686a60',0,2.67,0,tram);for(const z of [-1.8,1.8])for(const x of [-.7,.7]){const w=cylinder(.32,.15,'#3e423d',x,.44,z,tram);w.rotation.z=Math.PI/2;}const pole=box(.04,3,.04,'#514e43',0,4.05,-.3,tram);pole.rotation.x=.15;world.mergeDetails(tram);world.addGroup(tram,1.2,-55);block(1.2,-55,1.9,5.8);walls[walls.length-1].tram=true;
 for(const [name,x,z] of [['千田町',-4.1,28],['鷹野橋',-4.1,-32]]){const g=new THREE.Group();g.position.set(x,0,z);cylinder(.035,2,'#665e4d',0,1,0,g);world.addSign(name,g,0,1.8,.05,.9);world.addGroup(g,x,z);}
}
function landmarkModel(world,b){const g=new THREE.Group();g.position.set(b.x,0,b.z);g.userData.preBlast=true;
 const stone=surface('stone',b.id==='hiroden-senda'?'#a47c63':'#beb49c'),glass=mat('#71807b');texturedBox(b.w,b.h,b.d,stone,0,b.h/2,0,g);
 texturedBox(b.w+.4,.25,b.d+.4,surface('stone','#d4c9af'),0,b.h,0,g);
 for(const side of [-1,1])for(let x=-b.w/2+1;x<b.w/2;x+=1.5)for(let y=1.4;y<b.h-.3;y+=1.65){box(.72,1,.07,'#4e605e',x,y,side*(b.d/2+.04),g);box(.82,.08,.12,'#d0c4aa',x,y-.54,side*(b.d/2+.09),g);}
 if(b.id==='cityhall'){texturedBox(3.4,2.2,3,stone,0,b.h+1,0,g);box(3.7,.2,3.3,'#777a6e',0,b.h+2.2,0,g);}
 if(b.id==='bunrika'){texturedBox(4,b.h+.7,1.3,stone,0,b.h/2+.35,b.d/2+.4,g);for(const x of [-1.35,1.35])cylinder(.18,2.4,'#b8b29e',x,1.2,b.d/2+1.2,g);}
 if(b.id==='hiroden-senda'){box(b.w+.5,.25,b.d+.6,'#6c7069',0,b.h+.2,0,g);texturedBox(2,2.5,.1,surface('timber','#5b6357'),0,1.25,b.d/2+.1,g);}
 world.addSign(b.name,g,0,2.9,b.d/2+.18,Math.min(b.w*.65,5));world.mergeDetails(g);world.addGroup(g,b.x,b.z);world.buildings.push({id:b.id,position:{x:b.x,z:b.z},rotation:0,data:b,preBlastModel:g,postBlastModel:null,damageState:'INTACT',distanceFromHypocenter:b.historicalDistanceMetres});block(b.x,b.z,b.w,b.d);walls[walls.length-1].buildingId=b.id;
}
// Reuse the original tram meshes and footprint; only cached materials change.
function setTramDamage(post){
 const tram=world.tram;if(!tram)return;
 if(!tram.damageMaterials){
  tram.damageMaterials=[];
  const c=document.createElement('canvas');c.width=c.height=64;const g=c.getContext('2d');g.fillStyle='#282c2d';g.fillRect(0,0,64,64);
  g.strokeStyle='#8c8d80';g.lineWidth=1;g.beginPath();for(const [x,y]of [[4,2],[23,19],[18,36],[46,60],[33,32],[61,15],[33,32],[60,41]])g.lineTo(x,y);g.stroke();g.fillStyle='#101414';g.beginPath();g.moveTo(5,28);g.lineTo(28,23);g.lineTo(19,57);g.closePath();g.fill();
  const map=new THREE.CanvasTexture(c);map.colorSpace=THREE.SRGBColorSpace;
  const glass=new THREE.MeshLambertMaterial({map,color:'#747a77'});
  tram.traverse(m=>{if(!m.isMesh)return;const hex=m.material.color.getHexString(),damaged=hex==='516969'?glass:surface('char',hex==='d1c7a8'?'#777568':hex==='d6c9a7'?'#716b5b':'#4b4b43');tram.damageMaterials.push({mesh:m,pre:m.material,post:damaged});});
 }
 for(const entry of tram.damageMaterials)entry.mesh.material=post?entry.post:entry.pre;
 tram.userData.damageState=post?'DAMAGED':'INTACT';
}
function setDistrictMaterials(post){setTramDamage(post);if(world.preShadows)world.preShadows.visible=!post;for(const s of world.surfaces||[])s.mesh.material=post?s.post:s.pre;}

function districtShadows(world){const mesh=new THREE.InstancedMesh(new THREE.PlaneGeometry(1,1),new THREE.MeshBasicMaterial({color:'#343c34',transparent:true,opacity:.13,depthWrite:false}),world.buildings.length),o=new THREE.Object3D();for(const [i,b] of world.buildings.entries()){o.position.set(b.position.x-1,.045,b.position.z+1.5);o.rotation.set(-Math.PI/2,0,0);o.scale.set(b.data.w+1.8,b.data.d+2.6,1);o.updateMatrix();mesh.setMatrixAt(i,o.matrix);}mesh.userData.nonSolid=true;mesh.frustumCulled=false;scene.add(mesh);world.preShadows=mesh;}
