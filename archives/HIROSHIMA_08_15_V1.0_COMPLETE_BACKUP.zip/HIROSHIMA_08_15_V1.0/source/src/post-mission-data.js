// Fictional, non-graphic prototype scenes. These are not records of real individuals.
const POST_MISSION_STATES={
 M1_INACTIVE:'MISSION_1_INACTIVE',M1_ACTIVE:'MISSION_1_ACTIVE',M1_CHILD_FOUND:'MISSION_1_CHILD_FOUND',M1_RETURN:'MISSION_1_RETURN_TO_MOTHER',M1_COMPLETED:'MISSION_1_COMPLETED',
 M2_INACTIVE:'MISSION_2_INACTIVE',M2_ACTIVE:'MISSION_2_ACTIVE',M2_WATER_COLLECTED:'MISSION_2_WATER_COLLECTED',M2_RETURN:'MISSION_2_RETURN',M2_COMPLETED:'MISSION_2_COMPLETED',FIND_MASAMI:'FIND_MASAMI_ACTIVE'};
const POST_MISSION_DATA={childBuildingId:'block-17',motherId:'citizen-02',childId:'citizen-04',maleId:'citizen-05',
 motherPosition:{...GEO1945.missionPositions.mother},childPosition:{...GEO1945.missionPositions.child},malePosition:{...GEO1945.missionPositions.male},hydrantPosition:{...GEO1945.missionPositions.water},MASAMI_MIN_DISTANCE:45,
 missions:[{id:'post-child',title:'子どもを探して',giverNpcId:'citizen-02',targetNpcId:'citizen-04',state:'MISSION_1_INACTIVE'},
 {id:'post-water',title:'水をくれ',giverNpcId:'citizen-05',targetNpcId:'broken-hydrant',state:'MISSION_2_INACTIVE'}]};
const POST_SCENES={
 motherOffer:{id:'post-mother-offer',pages:['子どもが見つからないんです。西の路地に、屋根の傾いた家が残っています。','お願いです。あの辺りを、探してもらえませんか。'],choices:[{label:'探す',action:'post-accept-child'},{label:'今はできない',action:'decline'}]},
 childAccepted:{id:'post-child-accepted',pages:['一雄「分かりました。通れる道から探してきます。」','「西側の路地です。半分残った屋根を、目印にしてください。」']},
 motherWaiting:{id:'post-mother-waiting',pages:['西側の路地に、傾いた屋根の家があります。','……どうか、あの子を。']},
 rescue:{id:'post-rescue',pages:['一雄「待ってろ。今、出してやる。」','子ども「お母さん……。」','瓦礫に手をかけ、動かそうとする。','一雄「聞こえるか。もう少し……。」','子どもから、応答がなくなった。','一雄「……聞こえるか。」']},
 childCheck:{id:'post-child-check',pages:['呼びかけても、応答はなかった。','一雄「……お母さんのところへ戻ろう。」']},
 motherReport:{id:'post-mother-report',pages:['一雄「傾いた屋根の家で、見つけました。」','一雄「出そうとしたのですが……。助けられませんでした。」','母親「……そう、ですか。」','一雄は、その場にしばらく立ち止まった。']},
 motherAfter:{id:'post-mother-after',pages:['母親は、子どものいた方を見つめている。','千田町の南側で、水を求めている人がいるようだ。']},
 maleEarly:{id:'post-male-early',pages:['「……水……。」','男性はその場に身を寄せている。']},
 maleOffer:{id:'post-male-offer',pages:['「水……水を……。」','西の道で、破損した住宅給水管から水の流れる音がする。'],choices:[{label:'水を探す',action:'post-accept-water'},{label:'今はできない',action:'decline'}]},
 waterAccepted:{id:'post-water-accepted',pages:['一雄「水を探してくる。ここで待っていてくれ。」','西へ続く道で、水音を確かめよう。']},
 maleWaiting:{id:'post-male-waiting',pages:['男性は、目を閉じたまま待っている。']},
 hydrant:{id:'post-hydrant',pages:['破損した住宅給水管から、水が流れている。','水を汲みますか？'],choices:[{label:'はい',action:'post-collect-water'},{label:'いいえ',action:'decline'}]},
 collected:{id:'post-water-collected',pages:['一雄は水を汲んだ。','男性のもとへ戻ろう。']},
 maleDeadEarly:{id:'post-male-dead-early',pages:['呼びかけても、男性は応えない。','水を探し、もう一度戻ってこよう。']},
 maleConfirm:{id:'post-male-confirm',pages:['一雄「水を持ってきた。……聞こえるか。」','男性に、応答はなかった。','一雄は反応を確かめる。男性は、すでに亡くなっていた。','一雄「……マサミ。」']},
 maleAfter:{id:'post-male-after',pages:['男性は、呼びかけに応えない。']},
 down:{id:'post-down-check',pages:['一雄「声は、聞こえますか。」','短い応答が返る。今は、長く話せる様子ではない。']}
};
const POST_ROLE_VARIANTS={
 motherWaiting:[POST_SCENES.motherWaiting,{id:'post-mother-waiting-2',pages:['あの家の屋根だけが、傾いて残っているんです。','西の路地です。火のない方から……。']},{id:'post-mother-waiting-3',pages:['あの子の声が、聞こえた気がしたんです。','どうか、通れる道で確かめてください。']}],
 motherAfter:[POST_SCENES.motherAfter,{id:'post-mother-after-2',pages:['母親は、しばらく言葉を発しなかった。','一雄も、その場で息を整える。']},{id:'post-mother-after-3',pages:['「……探してくださって、ありがとう。」','小さな声が返ってきた。']}],
 maleEarly:[POST_SCENES.maleEarly,{id:'post-male-early-2',pages:['男性は、かすかに水を求めている。','まだ、長く話せる様子ではない。']},{id:'post-male-early-3',pages:['「……水を……。」','男性は身を動かさず、道の脇に座っている。']}],
 maleWaiting:[POST_SCENES.maleWaiting,{id:'post-male-waiting-2',pages:['「……頼む……。」','男性は、顔を上げようとしている。']},{id:'post-male-waiting-3',pages:['男性の呼吸が、わずかに聞こえる。','西の道の水音を確かめよう。']}]
};

// Authored, walkable search sites. Difficulty band matches the former northwest approach.
const MASAMI_SEARCH_RULES=Object.freeze({minimumDistance:POST_MISSION_DATA.MASAMI_MIN_DISTANCE,minimumRoute:95,maximumRoute:145,farPreference:.80});
const MASAMI_SEARCH_CANDIDATES=Object.freeze([
 {id:'northwest-bank',position:{x:-38,z:-47},region:'northwest'},
 {id:'west-backstreet',position:{x:-38,z:-39},region:'northwest'},
 {id:'west-north-lane',position:{x:-30,z:-47},region:'northwest'},
 {id:'northwest-crossing',position:{x:-22,z:-47},region:'northwest'},
 {id:'north-west-edge',position:{x:-14,z:-47},region:'north'},
 {id:'north-lane',position:{x:-6,z:-47},region:'north'},
 {id:'north-east-edge',position:{x:2,z:-47},region:'north'},
 {id:'east-north-lane',position:{x:10,z:-47},region:'northeast'},
 {id:'northeast-corner',position:{x:18,z:-47},region:'northeast'},
 {id:'east-backstreet',position:{x:18,z:-39},region:'northeast'},
 {id:'east-crossing',position:{x:26,z:-39},region:'northeast'},
 {id:'university-west-lane',position:{x:34,z:-39},region:'northeast'}
].map(c=>Object.freeze({...c,position:Object.freeze(c.position),coverType:'ruined-wall',difficultyScore:3})));

// Authored pairs: the story stays fixed while each play chooses a compatible route.
const MISSION_LOCATION_RULES=Object.freeze({minimumChildDistance:24,maximumChildDistance:42,minimumWaterDistance:65,maximumWaterDistance:100,minimumEventDistance:18,minimumWakeDistance:8,maximumChildRoute:75,minimumWaterRoute:85,maximumWaterRoute:155});
const MISSION1_MOTHER_CANDIDATES=[[-6,24],[6,24],[-12,18],[0,18],[6,12],[-18,24]].map(([x,z],i)=>({id:'mother-'+i,position:{x,z},difficultyScore:3}));
const MISSION1_CHILD_CANDIDATES=[[-30,12],[-24,6],[-36,18],[-24,0],[-18,0],[-18,-6]].map(([x,z],i)=>({id:'child-'+i,position:{x,z},coverType:'trapped-under-beams',difficultyScore:3}));
const MISSION2_MAN_CANDIDATES=[[18,42],[24,36],[30,30],[0,42],[12,42],[-12,42]].map(([x,z],i)=>({id:'man-'+i,position:{x,z},difficultyScore:3}));
const MISSION2_WATER_CANDIDATES=[[-24,-42],[-12,-36],[0,-42],[18,-36],[30,-42],[42,-36]].map(([x,z],i)=>({id:'water-'+i,position:{x,z},type:'broken-residential-pipe',difficultyScore:3}));
const MISSION1_SETS=MISSION1_MOTHER_CANDIDATES.map((m,i)=>({id:'m1-'+i,mother:m.id,child:MISSION1_CHILD_CANDIDATES[i].id}));
const MISSION2_SETS=MISSION2_MAN_CANDIDATES.map((m,i)=>({id:'m2-'+i,man:m.id,water:MISSION2_WATER_CANDIDATES[i].id}));
