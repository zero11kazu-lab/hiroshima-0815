let storyController=null,storyLayout=null;
class StoryController {
 constructor(manager,layout){this.manager=manager;this.layout=layout;this.reset();for(const n of manager.people){const info=this.informationFor(n);n.masamiInfo={level:info.level,stage:info.stage};}}
 reset(){this.state=MAIN_OBJECTIVES.BEFORE_0800;this.met=false;this.ended=false;this.endEventCount=0;this.inquiries=[];this.bestClue=null;this.lastSecond=-1;this.meetCount=0;$('prototype-end').hidden=true;}
 onTime(seconds){
  if(this.ended)return;
  if(seconds>=8*3600&&this.state===MAIN_OBJECTIVES.BEFORE_0800){this.state=MAIN_OBJECTIVES.FIND_MASAMI_BEFORE_BLAST;missionController?.render();if(dialogue?.active)dialogue.render();}
  if(seconds>=8*3600+15*60)on0815Event();
 }
 get canAsk(){return worldState===WORLD_STATE.PRE_BLAST&& this.state===MAIN_OBJECTIVES.FIND_MASAMI_BEFORE_BLAST&&!this.met&&!this.ended;}
 get primary(){return this.state!==MAIN_OBJECTIVES.BEFORE_0800;}
 markMet(){if(this.met)return;this.met=true;this.meetCount++;missionController.render();}
 informationFor(n){
  const side=this.layout.sideWord,far=this.layout.position,d=Math.hypot(n.position.x-far.x,n.position.z-far.z);
  const direction=Math.abs(n.position.x-far.x)>Math.abs(n.position.z-far.z)?(far.x<n.position.x?'西':'東'):(far.z<n.position.z?'北':'南');
  if(d<12)return {level:'accurate',stage:5,pages:[`マサミさんなら、この近くで見ましたよ。`,`${direction}側の家並みの間です。路地の奥を確かめてみてください。`],summary:`この近くの${direction}側。家並みの間にいるらしい。`};
  if(d<35||n.clueRole==='cornerWitness')return {level:'direction',stage:4,pages:[`鷹野橋の南の路地で見かけました。`,`${direction}へ進んで、家並みの間の道を確かめてください。`],summary:`鷹野橋の南の路地。この通りから${direction}へ。`};
  if(n.important||n.clueRole||n.index%4===2)return {level:'direction',stage:2,pages:['一雄さん、奥さんを探しているんですね。','布の用事で、北の鷹野橋の方へ行くと話していました。電車通りを北へ行って、また尋ねてみては。'],summary:'電車通りを北へ。鷹野橋・市役所南側で聞いてみよう。'};
  if(n.index%3===0)return {level:'stale',stage:0,pages:['朝早くなら、商店の辺りで見かけました。','でも、だいぶ前のことです。今いる場所は分かりません。'],summary:null};
  return {level:'none',stage:0,pages:[n.type==='child'?'今日はまだ見ていないよ。':'すみません、今日はまだ見かけていません。',n.index%2?'お店の人なら、何か聞いているかもしれません。':'近くを通った人にも、尋ねてみてはどうでしょう。'],summary:null};
 }
 inquire(n){
  const info=this.informationFor(n);n.masamiInfo={level:info.level,stage:info.stage,heardAt:gameClock.seconds};this.inquiries.push({npcId:n.id,level:info.level,stage:info.stage,at:gameClock.seconds});
  if(info.summary&&(!this.bestClue||info.stage>=this.bestClue.stage)){this.bestClue={stage:info.stage,text:info.summary,from:n.name};missionController.render();}
  return {id:'masami-inquiry-'+n.id,pages:['一雄「妻のマサミを見ませんでしたか？」',...info.pages],choices:[{label:'話の続きへ',action:'return-dialogue'}]};
 }
 snapshot(){return {player:{...PLAYER_PROFILE},phase:this.state,met:this.met,ended:this.ended,endEventCount:this.endEventCount,bestClue:this.bestClue?{...this.bestClue}:null,inquiryCount:this.inquiries.length};}
}

// Stable integration point for the next field transition.
function on0815Event(){if(storyController&&!event0815.active&&worldState===WORLD_STATE.PRE_BLAST)event0815.begin();}
