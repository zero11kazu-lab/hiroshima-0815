// All people and dialogue are fictional. No character has knowledge of a future event.
const PLAYER_PROFILE={id:'kazuo_nishimoto',name:'西本 一雄',reading:'にしもと かずお',role:'広島で暮らす一般市民',spouseId:'masami_nishimoto'};
const MAIN_OBJECTIVES={BEFORE_0800:'BEFORE_0800',FIND_MASAMI_BEFORE_BLAST:'FIND_MASAMI_BEFORE_BLAST',POST_BLAST_FIND_MASAMI:'POST_BLAST_FIND_MASAMI'};
const MASAMI_PROFILE={id:'masami_nishimoto',name:'西本 マサミ',type:'woman',occupation:'街で用事を済ませている',relationship:'一雄の妻',roleAction:'朝の用足し',important:true,homeRadius:1.7,startFraction:0,speed:.66,pause:5,schedule:[],missionFlags:{spouse:true},dialogue:[
 {id:'masami-first',firstOnly:true,pages:['一雄「マサミ、ここにいたのか。」','マサミ「どうしたの？ こんな朝早くに。」','一雄「用事がひと段落してね。顔を見に来たんだ。」','マサミ「そうだったの。私も、もう少ししたら戻るところよ。」']},
 {id:'masami-daily-1',pages:['マサミ「ここで布を受け取る用があったの。」','一雄「そうか。道で見かけなかったから、人に聞いてきたよ。」']},
 {id:'masami-daily-2',pages:['マサミ「歩いてきたら、少し暑くなってしまったわ。」','一雄「帰りは、風の通る道を歩こうか。」']},
 {id:'masami-daily-3',pages:['マサミ「清吉さんのお店は、もう開いていた？」','一雄「うん。いつものように支度をしていたよ。」']},
 {id:'masami-daily-4',pages:['マサミ「朝のうちに、一つ用事が済んでよかった。」','一雄「私も、少し街を歩いてきたところなんだ。」']}
]};

// Selected district, rather than a random far corner. Placement is a documented C-level staging choice.
function prepareStoryPopulation(){
 const position={x:GEO1945.masamiPre.x,z:GEO1945.masamiPre.z},side=-1,sideWord='西',nav=new Navigation(worldAllowed);
 const wife=JSON.parse(JSON.stringify(MASAMI_PROFILE));wife.homePosition=position;wife.routeId='masami-local';wife.route=[position,{x:position.x+.8,z:position.z}];NPC_DATA.push(wife);
 const witnesses=[{index:16,role:'riverWitness',x:0,z:-10},{index:18,role:'northRoadWitness',x:-26,z:-22},{index:10,role:'cornerWitness',x:-26,z:-37},{index:8,role:'nearWitness',x:-25,z:-47}];
 for(const w of witnesses){const n=NPC_DATA[w.index];n.clueRole=w.role;n.stayLocal=true;n.homePosition={x:w.x,z:w.z};n.homeRadius=2;n.schedule=[];n.startFraction=0;n.routeId='morning-'+w.role;n.route=[{x:w.x,z:w.z},{x:w.x+.7,z:w.z}];n.pause=2.5;}
 for(const n of NPC_DATA)n.masamiInfo={level:'none',source:'未確認'};
 return {position,side,sideWord,pathDistance:90,reachableCells:null,walkRoute:[],witnesses};
}
