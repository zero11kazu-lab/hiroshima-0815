// Player — 移動入力とカメラ連携は試作03を継承。
function createPlayer(){
player=new THREE.Group();scene.add(player);box(.55,.72,.32,'#727a61',0,1.05,0,player);box(.55,.35,.34,'#4a5148',0,.64,0,player);cylinder(.22,.35,'#c1a687',0,1.64,0,player);cylinder(.235,.13,'#535c4c',0,1.86,0,player);box(.32,.04,.18,'#535c4c',0,1.81,-.18,player);for(let s of [-1,1]){let leg=new THREE.Group();leg.position.set(s*.16,.58,0);player.add(leg);box(.2,.5,.23,'#4a5148',0,-.22,0,leg);box(.22,.12,.36,'#4b4539',0,-.5,-.05,leg);legs.push(leg);let arm=new THREE.Group();arm.position.set(s*.37,1.36,0);player.add(arm);box(.18,.48,.22,'#727a61',0,-.2,0,arm);box(.13,.14,.15,'#bda184',0,-.49,0,arm);arms.push(arm);}for(const x of [-.075,.075])box(.032,.035,.02,'#383c36',x,1.7,-.215,player);box(.065,.08,.06,'#b59a7f',0,1.63,-.23,player);for(const x of [-.09,.09])box(.12,.13,.04,'#c7c2a9',x,1.38,-.18,player);for(const y of [.92,1.08,1.24])box(.035,.035,.025,'#4b5146',0,y,-.18,player);let shadow=new THREE.Mesh(new THREE.CircleGeometry(.43,24),new THREE.MeshBasicMaterial({color:'#4b5240',transparent:true,opacity:.22,depthWrite:false}));shadow.rotation.x=-Math.PI/2;shadow.position.y=.07;player.add(shadow);

}

function updatePlayer(dt){
if(!playerControlEnabled||dialogue?.active){phase=0;legs.forEach(l=>l.rotation.x=0);arms.forEach(a=>a.rotation.x=0);return {x:0,y:0,n:0};}
let x=input.x,y=input.y;if(input.id===null){x=(keys.has('d')||keys.has('arrowright')?1:0)-(keys.has('a')||keys.has('arrowleft')?1:0);y=(keys.has('s')||keys.has('arrowdown')?1:0)-(keys.has('w')||keys.has('arrowup')?1:0);}let n=Math.hypot(x,y);if(n>1){x/=n;y/=n;n=1;}if(n>.08){const sin=Math.sin(cameraYaw+cameraAvoidYaw),cos=Math.cos(cameraYaw+cameraAvoidYaw);
const worldX=x*cos+y*sin,worldZ=-x*sin+y*cos;
const baseSpeed=worldState===WORLD_STATE.POST_BLAST&&survival.running?PLAYER_RUN_SPEED:PLAYER_WALK_SPEED;let nx=pos.x+worldX*baseSpeed*playerMoveScale*dt,nz=pos.z+worldZ*baseSpeed*playerMoveScale*dt;if(allowed(nx,pos.z))pos.x=nx;if(allowed(pos.x,nz))pos.z=nz;let target=Math.atan2(-worldX,-worldZ);yaw+=Math.atan2(Math.sin(target-yaw),Math.cos(target-yaw))*(1-Math.exp(-14*dt));phase+=dt*9*n*(worldState===WORLD_STATE.POST_BLAST&&survival.running?1.5:1);}else phase=0;player.position.set(pos.x,.08,pos.z);player.rotation.y=yaw;legs.forEach((l,i)=>l.rotation.x=Math.sin(phase+i*Math.PI)*.45);arms.forEach((a,i)=>a.rotation.x=-Math.sin(phase+i*Math.PI)*.35);
return {x,y,n};
}

// One cached 32px texture on existing meshes; no new geometry or draw calls.
function setPlayerDamageAppearance(post){
 if(!player)return;
 if(!player.preDamageMaterials){
  const entries=[];player.traverse(m=>{if(m.isMesh)entries.push({mesh:m,material:m.material});});player.preDamageMaterials=entries;
 }
 for(const e of player.preDamageMaterials){
  if(!post){e.mesh.material=e.material;continue;}
  if(!e.damaged){
   const m=e.material.clone(),hex=e.material.color.getHexString();
   if(['727a61','c1a687','bda184','b59a7f','c7c2a9'].includes(hex)){
    const canvas=document.createElement('canvas');canvas.width=canvas.height=32;const c=canvas.getContext('2d');
    c.fillStyle=hex==='727a61'?'#ad9177':'#aa8e74';c.fillRect(0,0,32,32);
    if(hex==='727a61'){c.fillStyle='#626951';c.beginPath();c.moveTo(0,0);c.lineTo(18,0);c.lineTo(14,10);c.lineTo(20,15);c.lineTo(12,23);c.lineTo(17,32);c.lineTo(0,32);c.fill();}
    c.fillStyle='#514a3e';c.fillRect(3,8,7,5);c.fillRect(23,24,6,4);c.fillStyle='#8a5d4e';c.fillRect(21,13,6,7);
    m.map=new THREE.CanvasTexture(canvas);m.map.colorSpace=THREE.SRGBColorSpace;m.color.set('#ffffff');
   }else m.color.multiplyScalar(.85);
   e.damaged=m;
  }e.mesh.material=e.damaged;
 }
 player.userData.damageAppearance=post?'KAZUO_LIGHT':'PRE';
}
