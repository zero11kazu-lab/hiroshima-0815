class PostMissionController {
 constructor(){this.root=null;this.reset();}
 reset(){this.missions=POST_MISSION_DATA.missions.map(m=>({...m}));this.mission1Completed=false;this.mission2Completed=false;this.masamiRepositioned=false;this.masamiSearch=null;this.locationPlan=null;this.masamiSeed=(Math.random()*0x100000000)>>>0;this.repositionCount=0;this.waterCollected=false;this.childState='CHILD_TRAPPED';this.maleState='MALE_WAITING';this.phase='POST_ORIENTATION';this.clock=0;this.trace=[];this.dialogueCounters={};this.checkpointState=null;this.rescuing=false;this.routes={};if(this.root)this.root.visible=false;}
 get canAskMasami(){return this.phase===POST_MISSION_STATES.FIND_MASAMI&&this.masamiRepositioned;}
 canAskNPC(n){return this.canAskMasami&&!n.isProp&&!n.hiddenFromWorld&&!['DEAD','CHILD_DEAD','DOWN','MISSING'].includes(n.postBlastState);}
 get mother(){return missionController.person(POST_MISSION_DATA.motherId);}
 get child(){return missionController.person(POST_MISSION_DATA.childId);}
 get male(){return missionController.person(POST_MISSION_DATA.maleId);}
 get wife(){return missionController.person(PLAYER_PROFILE.spouseId);}
 setup(){
  for(const [n,role,name,p] of [[this.mother,'mother','佐々木 千代',POST_MISSION_DATA.motherPosition],[this.child,'child','佐々木 実',POST_MISSION_DATA.childPosition],[this.male,'male','中村 俊夫',POST_MISSION_DATA.malePosition]]){n.name=name;n.postRole=role;n.position={...p};n.postAnchor={...p};n.hiddenFromWorld=false;n.postBlastState=role==='child'?'CHILD_TRAPPED':'STATIC';n.moving=false;}
  this.wife.hiddenFromWorld=true;this.wife.moving=false;this.wife.postBlastState='MISSING';this.hydrant={id:'broken-hydrant',name:'破損した住宅給水管',position:{...POST_MISSION_DATA.hydrantPosition},isProp:true};
  this.buildProps();this.syncActors();npcManager.grid.rebuild(npcManager.people);
 }
 buildProps(){
  if(!this.root){this.root=new THREE.Group();scene.add(this.root);const child=POST_MISSION_DATA.childPosition,g=new THREE.Group();g.position.set(child.x,0,child.z);this.root.add(g);this.childRubble=g;
   // Low beams cover the legs; the head and shoulders remain visible. No injury detail.
   box(1.35,.47,.8,'#62584a',0,.23,.19,g);for(const side of [-1,1]){const beam=box(.15,.14,1.45,'#4d473d',side*.43,.57,.1,g);beam.rotation.z=side*.12;}world.mergeDetails(g);
   const smoke=this.childSmoke=new THREE.Mesh(geometries.leaf,new THREE.MeshBasicMaterial({color:'#716c62',transparent:true,opacity:.18,depthWrite:false}));smoke.position.set(child.x-.6,3.4,child.z-2);smoke.scale.set(1.1,1.9,1);smoke.userData.nonSolid=true;this.root.add(smoke);
   this.waterRoot=new THREE.Group();this.root.add(this.waterRoot);texturedBox(1.3,.2,.8,surface('stone','#716b5d'),0,.1,0,this.waterRoot);cylinder(.09,.65,'#797164',0,.32,0,this.waterRoot);const pipe=cylinder(.1,.6,'#797164',.2,.5,0,this.waterRoot);pipe.rotation.z=1;
   this.water=new THREE.Group();this.waterRoot.add(this.water);const material=new THREE.MeshBasicMaterial({color:'#b8d6cf',transparent:true,opacity:.65,depthWrite:false});for(let i=0;i<6;i++){const m=new THREE.Mesh(geometries.cylinder,material);m.position.set(.2+i*.15,.7+Math.sin(i/5*Math.PI)*.7-i*.12,0);m.scale.set(.035,.35,.035);m.rotation.z=-.4+i*.18;m.userData.nonSolid=true;this.water.add(m);}const pool=new THREE.Mesh(new THREE.CircleGeometry(1.15,16),material);pool.rotation.x=-Math.PI/2;pool.position.set(.9,.08,0);pool.userData.nonSolid=true;this.waterRoot.add(pool);
  }this.root.visible=true;this.waterRoot.position.set(this.hydrant.position.x,0,this.hydrant.position.z);
 }
 // No arbitrary-coordinate fallback and no hazard removal: reject invalid authored pairs.
 validateLocations(){
  if(this.locationPlan)return;
  const rules=MISSION_LOCATION_RULES,distance=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z),cache=new Map();
  const route=(a,b)=>{const key=[a.x,a.z,b.x,b.z].join(',');if(!cache.has(key))cache.set(key,hazards.findRoute(a,b));return cache.get(key);};
  const length=r=>r.reduce((sum,p,i)=>sum+(i?distance(p,r[i-1]):0),0);
  const actors=[this.mother,this.child,this.male,this.wife];
  const safe=p=>{const s=hazards.sample(p.x,p.z);if(!worldAllowed(p.x,p.z)||s.heat>30||s.smoke>.08||s.contact>0)return false;
   // Reserve a small, walkable conversation/interaction margin.
   if(![[.65,1.25],[-.65,1.25],[.65,-1.25],[-.65,-1.25]].some(([x,z])=>worldAllowed(p.x+x,p.z+z)&&hazards.sample(p.x+x,p.z+z).heat<40&&hazards.sample(p.x+x,p.z+z).smoke<.10))return false;
   return !npcManager.grid.query(p.x,p.z,1).some(n=>!actors.includes(n)&&!n.hiddenFromWorld);
  };
  const ordered=(sets,key,salt)=>{let last=this.lastMissionSetIds?.[key]||null;try{last=localStorage.getItem(key)||last;}catch(_){}return [...sets].sort((a,b)=>(a.id===last)-(b.id===last)||hash10(this.masamiSeed+salt+sets.indexOf(a)*101)-hash10(this.masamiSeed+salt+sets.indexOf(b)*101));};
  const first=ordered(MISSION1_SETS,'hiroshima.lastMission1Set',1100),second=ordered(MISSION2_SETS,'hiroshima.lastMission2Set',2200);
  let chosen=null;
  for(const a of first){
   const mother=MISSION1_MOTHER_CANDIDATES.find(c=>c.id===a.mother).position,child=MISSION1_CHILD_CANDIDATES.find(c=>c.id===a.child).position;
   const d=distance(mother,child);if(d<rules.minimumChildDistance||d>rules.maximumChildDistance||distance(pos,mother)<rules.minimumWakeDistance||!safe(mother)||!safe(child))continue;
   const wake=route(pos,mother),rescue=route(mother,child);if(!wake.length||!rescue.length||length(rescue)>rules.maximumChildRoute)continue;
   for(const b of second){
    const man=MISSION2_MAN_CANDIDATES.find(c=>c.id===b.man).position,water=MISSION2_WATER_CANDIDATES.find(c=>c.id===b.water).position,wd=distance(man,water);
    if(wd<rules.minimumWaterDistance||wd>rules.maximumWaterDistance||!safe(man)||!safe(water)||[distance(mother,man),distance(child,man),distance(mother,water),distance(child,water)].some(d=>d<rules.minimumEventDistance))continue;
    const next=route(mother,man),supply=route(man,water),wl=length(supply);
    if(!next.length||!supply.length||wl<rules.minimumWaterRoute||wl>rules.maximumWaterRoute)continue;
    // Keep at least one non-clustered final-search site available for this pair.
    if(!MASAMI_SEARCH_CANDIDATES.some(c=>distance(c.position,water)>=rules.minimumEventDistance&&distance(c.position,man)>=MASAMI_SEARCH_RULES.minimumDistance+4&&safe(c.position)&&route(man,c.position).length&&length(route(man,c.position))>=MASAMI_SEARCH_RULES.minimumRoute&&length(route(man,c.position))<=MASAMI_SEARCH_RULES.maximumRoute))continue;
    chosen={mission1Set:a.id,mission2Set:b.id,mother:{...mother},child:{...child},man:{...man},water:{...water}};
    this.routes={wakeToMother:wake,motherToChild:rescue,motherToMale:next,maleToWater:supply};break;
   }if(chosen)break;
  }
  if(!chosen)throw Error('No safe reachable mission pair combination');
  this.locationPlan=chosen;
  for(const [n,p]of [[this.mother,chosen.mother],[this.child,chosen.child],[this.male,chosen.man]]){n.position={...p};n.postAnchor={...p};}
  this.hydrant.position={...chosen.water};this.childRubble.position.set(chosen.child.x,0,chosen.child.z);this.childSmoke.position.set(chosen.child.x-.6,3.4,chosen.child.z-2);this.waterRoot.position.set(chosen.water.x,0,chosen.water.z);
  for(const [key,id]of [['hiroshima.lastMission1Set',chosen.mission1Set],['hiroshima.lastMission2Set',chosen.mission2Set]]){this.lastMissionSetIds=this.lastMissionSetIds||{};this.lastMissionSetIds[key]=id;try{localStorage.setItem(key,id);}catch(_){}}
  if(EVENT_DEBUG)console.info('selectedMission1Set',chosen.mission1Set,'selectedMission2Set',chosen.mission2Set);
  this.syncActors();npcManager.grid.rebuild(npcManager.people);
 }

 syncActors(){
  if(!this.mother)return;this.mother.postBlastState='STATIC';this.child.postBlastState=this.childState;this.male.postBlastState=this.maleState==='MALE_DEAD'?'DEAD':'STATIC';this.wife.hiddenFromWorld=!this.masamiRepositioned;
  for(const n of [this.mother,this.child,this.male,this.wife]){if(['DEAD','CHILD_DEAD'].includes(n.postBlastState))n.conversing=false;n.moving=false;n.eventTilt=n.postBlastState==='DEAD'?1.12:n.postRole==='child'?.18:n.postRole==='male'?.6:.1;npcManager.visuals.write(n,!n.hiddenFromWorld&&Math.hypot(n.position.x-pos.x,n.position.z-pos.z)<world.visibleDistance);}npcManager.visuals.flush();
 }
 setState(index,state){this.missions[index].state=state;this.trace.push({state,at:this.clock});this.render();}
 render(){if(worldState===WORLD_STATE.POST_BLAST)missionController.render();}
 objective(){
  const s=POST_MISSION_STATES,a=this.missions[0].state,b=this.missions[1].state;
  if(this.canAskMasami)return {text:'マサミを探す',hint:survival.postClue?.text||'通れる道を確かめ、街の人に尋ねる'};
  if(a===s.M1_INACTIVE)return {text:'周囲を確かめ、人の声を探す',hint:`${masamiBearing(pos,this.mother.position)}の方で、人の声を探す`};
  if(a===s.M1_ACTIVE||a===s.M1_CHILD_FOUND)return {text:'母親の子どもを探す',hint:`母親から${masamiBearing(this.mother.position,this.child.position)}の方。傾いた梁の残る瓦礫を確かめる`};
  if(a===s.M1_RETURN)return {text:'母親のもとへ戻る',hint:'子どものことを母親に伝える'};
  if(b===s.M2_INACTIVE)return {text:'水を求める人を探す',hint:`母親のいた場所から${masamiBearing(this.mother.position,this.male.position)}の方で、人の声を探す`};
  if(b===s.M2_ACTIVE)return {text:'水を探す',hint:`男性のいた場所から${masamiBearing(this.male.position,this.hydrant.position)}の方。破損した住宅給水管の水音を探す`};
  return {text:'男性のもとへ水を届ける',hint:'水を求めていた男性のもとへ戻る'};
 }
 markerTarget(){const s=POST_MISSION_STATES,a=this.missions[0].state,b=this.missions[1].state;if([s.M1_INACTIVE,s.M1_RETURN].includes(a))return this.mother;if(this.mission1Completed&&[s.M2_INACTIVE,s.M2_RETURN,s.M2_WATER_COLLECTED].includes(b))return this.male;return null;}
 propTarget(p){return this.missions[1].state===POST_MISSION_STATES.M2_ACTIVE&&Math.hypot(p.x-this.hydrant.position.x,p.z-this.hydrant.position.z)<3.1?this.hydrant:null;}
 actionLabel(n){if(n.isProp)return '水を汲む';if(n.postRole==='child')return this.childState==='CHILD_TRAPPED'&&[POST_MISSION_STATES.M1_ACTIVE,POST_MISSION_STATES.M1_CHILD_FOUND].includes(this.missions[0].state)?'助ける':'確認する';if(n.postBlastState==='DEAD'||n.postBlastState==='DOWN')return '確認する';return '話す';}
 cloneNode(node){
  const copy={...node,pages:[...node.pages],choices:node.choices?.map(c=>({...c}))||[]};
  if(!this.locationPlan)return copy;
  const child=masamiBearing(this.mother.position,this.child.position),water=masamiBearing(this.male.position,this.hydrant.position),man=masamiBearing(this.mother.position,this.male.position);
  const replacements={
   'post-mother-offer':[`${child}の方で、子どもを見失ったんです。傾いた梁の残る瓦礫の辺りです。`,'お願いです。あの辺りを、探してもらえませんか。'],
   'post-child-accepted':['一雄「分かりました。通れる道から探してきます。」',`「${child}の方です。傾いた梁を、目印にしてください。」`],
   'post-mother-waiting':[`${child}の方に、傾いた梁の瓦礫があります。`,'……どうか、あの子を。'],
   'post-mother-waiting-2':['あの辺りに、梁が傾いて残っているんです。',`${child}の方です。火のない方から……。`],
   'post-mother-report':['一雄「瓦礫の下で、見つけました。」',...copy.pages.slice(1)],
   'post-mother-after':['母親は、子どものいた方を見つめている。',`${man}の方で、水を求めている人がいるようだ。`],
   'post-male-offer':['「水……水を……。」',`${water}の方の道から、破損した住宅給水管の水音がする。`],
   'post-water-accepted':['一雄「水を探してくる。ここで待っていてくれ。」',`${water}へ続く道で、水音を確かめよう。`],
   'post-male-waiting-3':['男性の呼吸が、わずかに聞こえる。',`${water}の道の水音を確かめよう。`]
  };
  if(replacements[copy.id])copy.pages=replacements[copy.id];return copy;
 }
 variant(key){const pool=POST_ROLE_VARIANTS[key],index=this.dialogueCounters[key]||0;this.dialogueCounters[key]=index+1;return this.cloneNode(pool[index%pool.length]);}
 nodeFor(n){const s=POST_MISSION_STATES,a=this.missions[0].state,b=this.missions[1].state;
  if(n.isProp)return this.cloneNode(POST_SCENES.hydrant);
  if(n.postRole==='mother'){if(a===s.M1_INACTIVE)return this.cloneNode(POST_SCENES.motherOffer);if(a===s.M1_RETURN)return this.cloneNode(POST_SCENES.motherReport);return this.variant(this.mission1Completed?'motherAfter':'motherWaiting');}
  if(n.postRole==='child'){if(a===s.M1_ACTIVE||a===s.M1_CHILD_FOUND){if(this.childState==='CHILD_TRAPPED'){this.setState(0,s.M1_CHILD_FOUND);return this.cloneNode(POST_SCENES.rescue);}return this.cloneNode(POST_SCENES.childCheck);}return this.cloneNode({id:'post-child-inactive',pages:['瓦礫の下に、小さな人影がある。','近くにいる人の話を確かめよう。']});}
  if(n.postRole==='male'){if(!this.mission1Completed)return this.variant('maleEarly');if(b===s.M2_INACTIVE)return this.cloneNode(POST_SCENES.maleOffer);if(this.maleState==='MALE_DEAD')return this.cloneNode(this.waterCollected&&!this.mission2Completed?POST_SCENES.maleConfirm:this.mission2Completed?POST_SCENES.maleAfter:POST_SCENES.maleDeadEarly);return this.variant('maleWaiting');}
  if(n.postBlastState==='DOWN'||n.postBlastState==='DEAD')return this.cloneNode(n.postBlastState==='DOWN'?POST_SCENES.down:{id:'post-still',pages:['呼びかけに、応答はなかった。']});return null;
 }
 choose(action){const s=POST_MISSION_STATES;
  if(action==='post-accept-child'&&this.missions[0].state===s.M1_INACTIVE){this.phase=s.M1_ACTIVE;this.setState(0,s.M1_ACTIVE);this.saveCheckpoint();return this.cloneNode(POST_SCENES.childAccepted);}
  if(action==='post-accept-water'&&this.mission1Completed&&this.missions[1].state===s.M2_INACTIVE){this.phase=s.M2_ACTIVE;this.setState(1,s.M2_ACTIVE);this.maleState='MALE_WAITING';this.saveCheckpoint();return this.cloneNode(POST_SCENES.waterAccepted);}
  if(action==='post-collect-water'&&this.missions[1].state===s.M2_ACTIVE){this.waterCollected=true;this.maleState='MALE_DEAD';this.setState(1,s.M2_WATER_COLLECTED);this.syncActors();return this.cloneNode(POST_SCENES.collected);}return null;
 }
 page(node,index){if(node.id==='post-rescue'){this.rescuing=index>=2&&index<=3;if(index>=4&&this.childState!=='CHILD_DEAD'){this.childState='CHILD_DEAD';this.syncActors();}}}
 finish(node,readAll){const s=POST_MISSION_STATES;this.rescuing=false;
  if(this.childState==='CHILD_DEAD'&&[s.M1_ACTIVE,s.M1_CHILD_FOUND].includes(this.missions[0].state))this.setState(0,s.M1_RETURN);
  if(node?.id==='post-mother-report'&&readAll&&!this.mission1Completed){this.mission1Completed=true;this.phase=s.M1_COMPLETED;this.setState(0,s.M1_COMPLETED);this.saveCheckpoint();}
  if(this.waterCollected&&this.missions[1].state===s.M2_WATER_COLLECTED)this.setState(1,s.M2_RETURN);
  if(node?.id==='post-male-confirm'&&readAll&&this.mission1Completed&&this.waterCollected&&!this.mission2Completed){this.mission2Completed=true;this.setState(1,s.M2_COMPLETED);this.repositionMasami();this.saveCheckpoint();}
 }
 // Runs once after the post-blast hazards and mission actor positions are settled.
 prepareMasamiSearch(){
  if(this.masamiSearch)return true;
  const start=this.male.position,rules=MASAMI_SEARCH_RULES;
  const eligible=[];
  for(const c of MASAMI_SEARCH_CANDIDATES){
   const p=c.position,s=hazards.sample(p.x,p.z),distance=Math.hypot(p.x-start.x,p.z-start.z);
   if((this.locationPlan&&[this.locationPlan.mother,this.locationPlan.child,this.locationPlan.water].some(q=>Math.hypot(q.x-p.x,q.z-p.z)<MISSION_LOCATION_RULES.minimumEventDistance))||!worldAllowed(p.x,p.z)||distance<rules.minimumDistance+4||s.heat>22||s.smoke>.08||npcManager.grid.query(p.x,p.z,1).some(n=>n!==this.wife&&!n.hiddenFromWorld))continue;
   const route=hazards.findRoute(start,p);if(!route.length||npcManager.navigation.segmentClear(start,p))continue;
   const length=route.reduce((sum,q,i)=>sum+(i?Math.hypot(q.x-route[i-1].x,q.z-route[i-1].z):0),0);
   if(length<rules.minimumRoute||length>rules.maximumRoute)continue;
   eligible.push({...c,distance,routeLength:length});
  }
  if(!eligible.length)throw Error('No reachable Masami search candidate');
  const farthest=Math.max(...eligible.map(c=>c.distance));let pool=eligible.filter(c=>c.distance>=farthest*rules.farPreference);
  let last=null;try{last=localStorage.getItem('hiroshima.lastMasamiSpawnId');}catch(_){}
  if(pool.length>1&&pool.some(c=>c.id!==last))pool=pool.filter(c=>c.id!==last);
  const selected=pool[Math.floor(hash10(this.masamiSeed)*pool.length)];
  this.masamiSearch={id:selected.id,position:{...selected.position},region:selected.region,coverType:selected.coverType,difficultyScore:selected.difficultyScore,routeLength:selected.routeLength};
  this.wife.position={...selected.position};this.wife.postAnchor={...selected.position};this.wife.hiddenFromWorld=true;this.wife.postBlastState='MISSING';this.wife.moving=false;
  npcManager.grid.rebuild(npcManager.people);npcManager.visuals.write(this.wife,false);npcManager.visuals.flush();
  try{localStorage.setItem('hiroshima.lastMasamiSpawnId',selected.id);}catch(_){}
  return true;
 }
 repositionMasami(){if(!this.mission1Completed||!this.mission2Completed||this.masamiRepositioned)return false;
  if(!this.masamiSearch)this.prepareMasamiSearch();
  const p=this.masamiSearch.position;
  // The existing NPC has occupied this position since world generation; never teleport it on discovery.
  if(Math.hypot(p.x-pos.x,p.z-pos.z)<MASAMI_SEARCH_RULES.minimumDistance)return false;
  const route=hazards.findRoute(pos,p);if(!route.length)return false;
  hazards.addFinalArea(pos,p);this.masamiRoute=hazards.addFinalCover(pos,p);
  if(!this.masamiRoute.length)throw Error('Masami search route blocked');
  this.wife.hiddenFromWorld=false;this.wife.postBlastState='SEARCHING';this.masamiRepositioned=true;this.repositionCount++;this.phase=POST_MISSION_STATES.FIND_MASAMI;storyController.state=MAIN_OBJECTIVES.POST_BLAST_FIND_MASAMI;
  this.trace.push({state:this.phase,at:this.clock});npcManager.grid.rebuild(npcManager.people);this.syncActors();survival.postClue=null;this.render();return true;
 }

 update(dt){this.clock+=dt;if(this.missions[1].state===POST_MISSION_STATES.M2_ACTIVE&&this.maleState==='MALE_WAITING'&&Math.hypot(pos.x-this.male.position.x,pos.z-this.male.position.z)>12){this.maleState='MALE_DEAD';this.syncActors();}
  if(this.rescuing&&dialogue.active?.postRole==='child'){arms.forEach(a=>a.rotation.x=-1.15);player.rotation.x=.18;}else if(player.rotation.x&&playerControlEnabled)player.rotation.x=0;
  if(this.water)this.water.scale.y=1+.06*Math.sin(this.clock*5);
 }
 serial(){return {locationPlan:this.locationPlan?JSON.parse(JSON.stringify(this.locationPlan)):null,masamiSeed:this.masamiSeed,masamiSearch:this.masamiSearch?{...this.masamiSearch,position:{...this.masamiSearch.position}}:null,missions:this.missions.map(m=>({...m})),mission1Completed:this.mission1Completed,mission2Completed:this.mission2Completed,waterCollected:this.waterCollected,childState:this.childState,maleState:this.maleState,masamiRepositioned:this.masamiRepositioned,repositionCount:this.repositionCount,phase:this.phase,trace:this.trace.map(t=>({...t}))};}
 saveCheckpoint(){if(!survival.active)return;this.checkpointState=this.serial();survival.checkpoint={position:{...pos},yaw,cameraYaw,npcs:npcManager.people.map(n=>({id:n.id,position:{...n.position},yaw:n.yaw,postBlastState:n.postBlastState,hiddenFromWorld:!!n.hiddenFromWorld})),storyPhase:storyController.state};}
 restoreCheckpoint(){if(!this.checkpointState)return;Object.assign(this,JSON.parse(JSON.stringify(this.checkpointState)));this.rescuing=false;this.syncActors();npcManager.grid.rebuild(npcManager.people);}
 snapshot(){return {...this.serial(),routes:Object.fromEntries(Object.entries(this.routes).map(([k,v])=>[k,v.length])),masamiPosition:this.masamiRepositioned?{...this.wife.position}:null};}
}
const postMissions=new PostMissionController();
