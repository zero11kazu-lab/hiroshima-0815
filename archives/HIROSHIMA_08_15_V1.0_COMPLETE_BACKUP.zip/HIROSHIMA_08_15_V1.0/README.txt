HIROSHIMA 08:15
Version 1.0
制作：ニッシー

内容：1945年8月6日の広島を題材とした短編3Dストーリーゲーム。

【起動方法】
起点は、このREADMEと同じ階層の index.html です。
assets/ と index.html の位置関係を保ったまま、フォルダ全体を静的Webサーバーへ配置し、ブラウザで開いてください。既存公開サイトやChatGPTの接続はゲームの実行には必要ありません。
PCの対応ブラウザではindex.htmlを直接開くことも可能ですが、iPhoneのファイルアプリ内プレビューはWebGLや音声実行を保証しないため、HTTP(S)での配信を推奨します。
開発者向け例：展開フォルダで python3 -m http.server 8000 を実行し、http://localhost:8000/ を開きます。通常のプレイヤーにPythonは不要です。
音声は最初のタップ後に有効になります。

【動作環境】
iPhone Safariを主対象。WebGL・WebAudioに対応したブラウザ、JavaScript有効。
iPhone Safari実機での動作・FPSはこのバックアップ作成では未検証です。
ゲームは複数ファイル構成です。HTMLファイルだけを単独で移動しないでください。

【構成】
index.html：公開版と同一の実行HTML。CSS・Three.js・ゲームJS・地理JSONを内包。
assets/title/：原爆ドーム背景、作者・ライセンス表記。
assets/ending/：慰霊碑背景。
assets/docs/hiroshima_history_map_design.pdf：歴史考証・マップ設計の原本PDF（29ページ）。
source/：元プロジェクトの追跡ファイルをそのまま収録。src/、data/、assets/、dist/、build.py、tests/、docs/、README、.openai/hosting.json。
MANIFEST_SHA256.json：各ファイルのSHA256。マニフェスト自身は含まない。
ASSET_AUDIT.json：参照アセットの存在確認・外部依存記録。

【再構築】
source/内で python3 build.py を実行すると source/dist/index.html と source/dist/assets/ を再構築できます。Python標準ライブラリのみを使用。Node/npmはビルドに不要です。
収録テストは開発時のPlaywrightパスやローカルポート、過去のGitコミットを参照するものがあります。これはゲーム実行依存ではありません。テスト環境やGit履歴そのものは含みません。

【音声・3D・テクスチャ】
タイトルBGM、投下前・投下後・エンディングBGM、爆発・火災・風・航空機・足音等はWebAudioで生成します。独立したMP3/WAVの不足ではありません。生成コード・楽譜データをsource/src/と実行HTMLに同梱しています。
建物、NPC、屋根、瓦礫等は手続き生成geometryとJSONから生成します。外部GLB/OBJは使用していません。
木・土壁・道路・炎・煙等のテクスチャは主にCanvasで生成。生成コードも同梱しています。
フォントはOSの明朝・serif等のフォールバック設定を使用します。外部フォント配信への依存はなく、OSにより字形が異なります。

【外部依存・公開URL】
ゲーム実行に必須の外部CDN・外部APIはありません。Three.jsはローカル同梱（MIT、2010-2023 Three.js Authors）。
クレジットの写真出典・CC BY 2.5ライセンスURL、史料の出典URL、Three.jsの案内URLは外部サイトです。画像表示・ゲーム起動に必要なダウンロード先ではありません。
タイトル写真の帰属表記はassets/title/ATTRIBUTION.txtとゲーム内クレジットを参照。
source/.openai/hosting.jsonには元Sitesのproject_idが残っています。資料やゲームの起動に使うURLではありません。他ホストでの復元にこの設定は不要です。
source/docs等には旧公開URLや開発環境のパス・ポートが記載されている場合がありますが、実行コードはchatgpt.siteの公開URLに依存しません。
既存公開サイトのアクセス制御・ホスティング環境・共有設定・個人のlocalStorage履歴はZIPに含みません。

【保存範囲】
ゲーム実行ファイルと現在の追跡済みソースを保存しています。.git、認証情報、環境変数、未追跡の古い検証スクリーンショットは含みません。
元プロジェクトの編集・ビルド・commit・push・公開版更新は行っていません。
